package UserProvisioningNov26;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserProvisioningApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserProvisioningApplication.class, args);
    }
}
