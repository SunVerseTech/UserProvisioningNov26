package UserProvisioningNov26.controller;

import UserProvisioningNov26.model.UserProvisioningForm;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

@Controller
public class PageController {

    private static final DateTimeFormatter TODAY_FORMAT =
            DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.ENGLISH);

    @GetMapping("/")
    public String root() {
        return "redirect:/welcome";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/welcome")
    public String welcome(Authentication authentication, Model model) {
        model.addAttribute("userName", authentication.getName());
        model.addAttribute("today", LocalDate.now().format(TODAY_FORMAT));
        return "welcome";
    }

    @GetMapping("/provisioning")
    public String provisioningForm(Model model) {
        if (!model.containsAttribute("form")) {
            model.addAttribute("form", new UserProvisioningForm());
        }
        addOptions(model);
        return "provisioning";
    }

    @PostMapping("/provisioning")
    public String save(@Valid @ModelAttribute("form") UserProvisioningForm form,
                       BindingResult bindingResult,
                       Model model,
                       RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            addOptions(model);
            return "provisioning";
        }
        // Save is a placeholder: nothing is stored, only a confirmation is shown.
        redirectAttributes.addFlashAttribute("confirmation",
                "User Provisioning is completed for " + form.getFirstName() + " " + form.getLastName());
        return "redirect:/provisioning";
    }

    private void addOptions(Model model) {
        model.addAttribute("salutations", List.of("Mr", "Ms", "Miss", "Mrs", "Dr", "Prof"));
        model.addAttribute("employmentStatuses", List.of("Active", "Deactivated", "Leave Of Absence", "Terminated"));
        model.addAttribute("states", List.of("New York", "California", "New Jersey", "Connecticut"));
        model.addAttribute("countries", List.of("USA", "Canada", "India"));
        model.addAttribute("responsibilities", List.of(
                "Investigation Supervisor Admin Resp",
                "Case Review Supervisor Resp",
                "Quality Care Specialist Resp"));
        model.addAttribute("positions", List.of("Investigator", "Field Officer", "Incident Reviewer"));
    }
}
