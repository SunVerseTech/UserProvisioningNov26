# UserProvisioningNov26

Spring Boot 3.5 / Java 21 / Maven application using Spring MVC, Thymeleaf, Spring Security (form login) and Bootstrap 5.

Pages: Login -> Welcome (Next) -> User Provisioning form (Save / Cancel).

Login: User ID `Sunooj`, Password `Password` (set in `src/main/resources/application.properties`).

## Run in IntelliJ IDEA

1. Install JDK 21 (IntelliJ: File > Project Structure > Project > SDK > Add SDK > Download JDK > version 21).
2. Unzip the project, then File > Open and select the project's `pom.xml` (or the folder). Choose "Open as Project" and trust the project.
3. Wait for the Maven import to finish (progress bar at the bottom). If needed, click the Maven tool window > Reload All Maven Projects.
4. Confirm File > Project Structure > Project: SDK = 21 and Language level = 21.
5. Open `src/main/java/UserProvisioningNov26/UserProvisioningApplication.java` and click the green Run arrow next to `main`.
   Alternative: Maven tool window > Plugins > spring-boot > spring-boot:run.
6. Open http://localhost:8080 in a browser and log in with `Sunooj` / `Password`.
7. Click Next on the welcome page to open the User Provisioning form.
8. Stop the app with the red Stop button in the Run window.

If port 8080 is in use, add `server.port=8081` to `application.properties`.

## Run from a terminal

    ./mvnw spring-boot:run        (macOS/Linux)
    mvnw.cmd spring-boot:run      (Windows)

The first run downloads Maven 3.9.9 into `~/.m2/wrapper`. To build a jar: `./mvnw clean package`, then `java -jar target/UserProvisioningNov26-1.0.0.jar`.
