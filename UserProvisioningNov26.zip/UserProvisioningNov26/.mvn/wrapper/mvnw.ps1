$ErrorActionPreference = 'Stop'
$props = Join-Path $PSScriptRoot 'maven-wrapper.properties'
$url = ((Get-Content $props | Where-Object { $_ -match '^distributionUrl=' }) -replace '^distributionUrl=', '').Trim()
$name = [System.IO.Path]::GetFileName($url) -replace '-bin\.zip$', ''
$userHome = if ($env:MAVEN_USER_HOME) { $env:MAVEN_USER_HOME } else { Join-Path $env:USERPROFILE '.m2' }
$dist = Join-Path $userHome "wrapper\dists\$name"
$mvn = Join-Path $dist "$name\bin\mvn.cmd"
if (-not (Test-Path $mvn)) {
    New-Item -ItemType Directory -Force -Path $dist | Out-Null
    $zip = Join-Path $dist "$name-bin.zip"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Write-Host "Downloading Maven: $url"
    Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
    Expand-Archive -Path $zip -DestinationPath $dist -Force
    Remove-Item $zip
}
& $mvn @args
exit $LASTEXITCODE
